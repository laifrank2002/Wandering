var inventory_panel_manager = {
    init: function() {
        
    },
    
    display_inventory: function() {
        
    },
    
    update_inventory: function() {
    
    },
};

//alias
var IPM = inventory_panel_manager;
