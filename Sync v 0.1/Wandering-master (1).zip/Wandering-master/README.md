# Wandering

> Where am I? How did I get here?

To-do list:
- [x] What do we want to do anyway?
- [ ] Build a web engine
- [ ] Plan out game modules
- [ ] Build the modules
- [ ] Plan some more
- [ ] Iron all the bugs out
- [ ] 10 GOTO 9

## License

Wandering is available under the MIT license. For more information, see LICENSE.md.

## Documentation

For documentation, please see the [wiki](https://github.com/LukeCastellan/Wandering/wiki).
