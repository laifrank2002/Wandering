// Inits everything.
// Data is hardcoded in, in lieu of a better method.
var path = ["Map of Wandering.png","map_wandering.png"];
var testLibrary = new ImageLibrary(path);

// Main function. 
updateCanvas();