/* Currently getting errors 
var MAP_TILES = {
    PLAYER = "§",
    FARM = "ƒ",
    OUTPOST = "R",
    PATH = "_",
    BRIDGE = "-",

    SPECIAL = "X", //to catch the player's attention. IMMEDIATELY!!!!!!!

    //various types of terrain
    FOREST = "T",
    MARSH = "m", //fill that in later
    WATER = "~",
    MOUNTAINS = "^",
    PLAINS = "w",
};
*/